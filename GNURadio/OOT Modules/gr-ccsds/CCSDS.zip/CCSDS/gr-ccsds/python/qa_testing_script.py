

print "Testing Portions of the QA Script"

	
f = open('bit_in.txt', 'r')
print "test: ", map(int,f.read().splitlines())
        

